// server.js

const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const multer = require('multer');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const path = require('path');
const fs = require('fs');

const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;
const MONGO_URI = 'mongodb://localhost:27017/venconnect';
const JWT_SECRET = 'your_secret_key_here';
const JWT_EXPIRY = '7d';

// Upload setup
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `${file.fieldname}-${unique}${ext}`);
  }
});
const upload = multer({ storage });

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(uploadDir));

// Database
mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

// Schemas
const userSchema = new mongoose.Schema({
  name: String,
  username: { type: String, unique: true, sparse: true },
  email: { type: String, unique: true },
  passwordHash: String,
  phone: String,
  location: String,
  shopName: String,
  bio: String,
  shopLogo: String,
  role: { type: String, enum: ['vendor', 'customer'], required: true }
});
const User = mongoose.model('User', userSchema);

const productSchema = new mongoose.Schema({
  vendorId: mongoose.Schema.Types.ObjectId,
  name: String,
  price: Number,
  currency: String,
  image: String,
  createdAt: { type: Date, default: Date.now }
});
const Product = mongoose.model('Product', productSchema);

const videoSchema = new mongoose.Schema({
  vendorId: mongoose.Schema.Types.ObjectId,
  video: String,
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  createdAt: { type: Date, default: Date.now }
});
const Video = mongoose.model('Video', videoSchema);

const reviewSchema = new mongoose.Schema({
  vendorId: mongoose.Schema.Types.ObjectId,
  customerId: mongoose.Schema.Types.ObjectId,
  customerName: String,
  rating: Number,
  review: String,
  createdAt: { type: Date, default: Date.now }
});
const Review = mongoose.model('Review', reviewSchema);
const messageSchema = new mongoose.Schema({
  from: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  to: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  text: String,
  video: String,
  read: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});
const Message = mongoose.model('Message', messageSchema);
// Auth middleware
function requireAuth(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.status(401).send('Unauthorized');
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    return res.status(403).send('Invalid token');
  }
}

// Auth routes
app.post('/login', async (req, res) => {
  const { usernameOrEmail, password } = req.body;
  try {
    const user = await User.findOne({
      $or: [{ username: usernameOrEmail }, { email: usernameOrEmail }]
    });
    if (!user) return res.json({ success: false, message: 'User not found' });

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) return res.json({ success: false, message: 'Incorrect password' });

    const payload = {
      id: user._id,
      username: user.username || user.email,
      role: user.role,
      shopName: user.shopName || ''
    };

    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRY });
    res.cookie('token', token, {
      httpOnly: true,
      sameSite: 'strict',
      maxAge: 1000 * 60 * 60 * 24 * 7
    }).json({ success: true, role: user.role });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

app.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.send('Logged out');
});

// Signup routes
app.post('/signup-vendor', upload.single('shopLogo'), async (req, res) => {
  const { name, shopName, email, password, location, bio } = req.body;
  const shopLogo = req.file?.filename;
  if (!name || !shopName || !email || !password || !location || !bio || !shopLogo) {
    return res.send("All fields are required.");
  }

  try {
    const existing = await User.findOne({ $or: [{ username: shopName }, { email }] });
    if (existing) return res.send("Shop name or email already taken.");

    const passwordHash = await bcrypt.hash(password, 10);
    const newUser = new User({
      name,
      username: shopName,
      shopName,
      email,
      passwordHash,
      location,
      bio,
      shopLogo,
      role: 'vendor'
    });

    await newUser.save();
    res.send("Vendor registered. You may now log in.");
  } catch (error) {
    console.error(error);
    res.status(500).send("Something went wrong.");
  }
});

app.post('/signup-customer', async (req, res) => {
  const { name, email, phone, password } = req.body;
  if (!name || !email || !phone || !password) return res.send("All fields are required.");

  try {
    const existing = await User.findOne({ email });
    if (existing) return res.send("Email already registered.");

    const passwordHash = await bcrypt.hash(password, 10);
    const newUser = new User({ name, email, phone, passwordHash, role: 'customer' });
    await newUser.save();
    res.send("Customer registered. You may now log in.");
  } catch (error) {
    console.error(error);
    res.status(500).send("Something went wrong.");
  }
});

app.get('/me', requireAuth, async (req, res) => {
  const user = await User.findById(req.user.id);
  res.json({
    username: user.username || user.email,
    shopName: user.shopName || '',
    role: user.role
  });
});

// Shop Routes
app.get('/api/my-shop', requireAuth, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user || user.role !== 'vendor') return res.status(404).send('No shop');
  res.json({
    shopName: user.shopName,
    bio: user.bio,
    location: user.location,
    shopLogo: user.shopLogo,
    _id: user._id
  });
});

app.post('/api/shops', requireAuth, upload.none(), async (req, res) => {
  const { shopName, bio, location } = req.body;
  const user = await User.findById(req.user.id);
  if (!user || user.role !== 'vendor') return res.status(403).send('Only vendors allowed');
  user.shopName = shopName;
  user.bio = bio;
  user.location = location;
  await user.save();
  res.json({ shopName, bio, location, shopLogo: user.shopLogo });
});

app.get('/api/shops', async (req, res) => {
  const query = req.query.search || '';
  const regex = new RegExp(query, 'i');

  try {
    // First, get vendors matching bio/location/shopName
    const vendorsByProfile = await User.find({
      role: 'vendor',
      $or: [
        { shopName: regex },
        { bio: regex },
        { location: regex }
      ]
    });

    // Then, get vendor IDs that have products matching the search
    const matchingProducts = await Product.find({ name: regex });
    const productVendorIds = [...new Set(matchingProducts.map(p => p.vendorId.toString()))];

    // Combine vendor IDs from both sources
    const allVendorsMap = new Map();
    vendorsByProfile.forEach(v => allVendorsMap.set(v._id.toString(), v));

    const additionalVendors = await User.find({
      _id: { $in: productVendorIds },
      role: 'vendor'
    });

    additionalVendors.forEach(v => allVendorsMap.set(v._id.toString(), v));

    const allVendors = Array.from(allVendorsMap.values());

    // Format result
    const result = allVendors.map(v => ({
      shopName: v.shopName,
      shopLogo: v.shopLogo || 'default.png',
      location: v.location,
      bio: v.bio,
      rating: 4.5
    }));

    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to fetch shops');
  }
});

// Product Routes
app.post('/api/products', requireAuth, upload.single('image'), async (req, res) => {
  const { name, price, currency } = req.body;
  const image = req.file.filename;
  const prod = new Product({ vendorId: req.user.id, name, price, currency, image });
  await prod.save();
  res.json({ success: true });
});

app.get('/api/products/mine', requireAuth, async (req, res) => {
  const products = await Product.find({ vendorId: req.user.id });
  res.json(products);
});

// Video Routes
app.post('/api/videos', requireAuth, upload.single('video'), async (req, res) => {
  const video = req.file.filename;
  const vid = new Video({ vendorId: req.user.id, video });
  await vid.save();
  res.json({ success: true });
});

app.get('/api/videos/mine', requireAuth, async (req, res) => {
  const videos = await Video.find({ vendorId: req.user.id });
  res.json(videos);
});

app.get('/api/videos/explore', async (req, res) => {
  const videos = await Video.find().sort({ createdAt: -1 }).limit(50);
  res.json(await Promise.all(videos.map(async v => {
    const vendor = await User.findById(v.vendorId);
    return {
      _id: v._id,
      video: v.video,
      createdAt: v.createdAt,
      likes: v.likes.length,
      vendor: {
        id: vendor._id,
        name: vendor.shopName || vendor.name,
        shopLogo: vendor.shopLogo || null
      }
    };
  })));
});

app.post('/api/videos/:id/like', requireAuth, async (req, res) => {
  const video = await Video.findById(req.params.id);
  if (!video) return res.status(404).send('Video not found');

  const alreadyLiked = video.likes.includes(req.user.id);
  if (alreadyLiked) {
    video.likes.pull(req.user.id);
  } else {
    video.likes.push(req.user.id);
  }

  await video.save();
  res.json({ liked: !alreadyLiked, totalLikes: video.likes.length });
});

app.delete('/api/videos/:id', requireAuth, async (req, res) => {
  const { id } = req.params;
  await Video.deleteOne({ _id: id, vendorId: req.user.id });
  res.send('Deleted');
});

// Reviews
app.get('/api/reviews/:vendorId', async (req, res) => {
  const reviews = await Review.find({ vendorId: req.params.vendorId }).sort({ createdAt: -1 });
  res.json(reviews);
});

app.post('/api/reviews/:vendorId', requireAuth, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (user.role !== 'customer') return res.status(403).send('Only customers can review');

  const { rating, review } = req.body;
  if (!rating || rating < 1 || rating > 5 || !review) {
    return res.status(400).send('Invalid rating or review');
  }

  const newReview = new Review({
    vendorId: req.params.vendorId,
    customerId: req.user.id,
    customerName: user.name,
    rating,
    review
  });

  await newReview.save();
  res.send('Review submitted');
});
app.get('/api/inbox', requireAuth, async (req, res) => {
  const messages = await Message.aggregate([
    { $match: { to: new mongoose.Types.ObjectId(req.user.id) } },
    { $sort: { createdAt: -1 } },
    {
      $group: {
        _id: '$from',
        lastMessage: { $first: '$text' },
        fromId: { $first: '$from' }
      }
    }
  ]);

  const enriched = await Promise.all(messages.map(async m => {
    const user = await User.findById(m.fromId);
    const unreadCount = await Message.countDocuments({
      from: m.fromId,
      to: req.user.id,
      read: false
    });

    return {
      fromId: m.fromId,
      fromName: user?.shopName || user?.name || 'Unknown',
      lastMessage: m.lastMessage,
      unreadCount
    };
  }));

  res.json(enriched);
});
app.get('/api/messages/:userId', requireAuth, async (req, res) => {
  const messages = await Message.find({
    $or: [
      { from: req.user.id, to: req.params.userId },
      { from: req.params.userId, to: req.user.id }
    ]
  }).sort({ createdAt: 1 });

  res.json(messages.map(m => ({
    text: m.text,
    isMine: m.from.toString() === req.user.id,
    video: m.video || null,
    createdAt: m.createdAt
  })));
});
app.post('/api/messages/:userId', requireAuth, async (req, res) => {
  const { text, video } = req.body;
  if (!text && !video) return res.status(400).send('Empty message');

  const msg = new Message({
    from: req.user.id,
    to: req.params.userId,
    text,
    video,
    read: false
  });

  await msg.save();
  io.to(req.params.userId).emit('new-message', {
  from: req.user.id,
  text,
  video: video || null,
  createdAt: msg.createdAt
});

res.send('Message sent');
});
app.patch('/api/messages/:userId/mark-read', requireAuth, async (req, res) => {
  await Message.updateMany(
    { from: req.params.userId, to: req.user.id, read: false },
    { $set: { read: true } }
  );
  res.send('Messages marked as read');
});
// Public shop view
app.get('/s/:id', async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user || user.role !== 'vendor') return res.status(404).send('Shop not found');

  const products = await Product.find({ vendorId: user._id });
  const videos = await Video.find({ vendorId: user._id });

  res.json({
    shop: {
      shopName: user.shopName,
      bio: user.bio,
      location: user.location,
      shopLogo: user.shopLogo
    },
    products,
    videos
  });
});
io.on('connection', socket => {
  console.log('User connected:', socket.id);

  socket.on('join', userId => {
    socket.join(userId);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

http.listen(PORT, () => {
  console.log(`Socket.IO server running at http://localhost:${PORT}`);
});

